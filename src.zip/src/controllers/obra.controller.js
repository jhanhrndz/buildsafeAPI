const obraService = require('../services/obra.service');

const getAllObras = async (req, res) => {
  try {
    const obras = await obraService.getAllObras();
    res.json(obras);
  } catch (error) {
    console.error('Error al obtener obras:', error.message);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const getObraById = async (req, res) => {
  try {
    const obra = await obraService.getObraById(req.params.id);
    if (!obra) {
      return res.status(404).json({ mensaje: 'Obra no encontrada' });
    }
    res.json(obra);
  } catch (error) {
    console.error('Error al obtener obra:', error.message);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const createObra = async (req, res) => {
  try {
    const id = await obraService.createObra(req.body);
    res.status(201).json({ mensaje: 'Obra creada correctamente', id_obra: id });
  } catch (error) {
    console.error('Error al crear obra:', error.message);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const updateObra = async (req, res) => {
  try {
    const updated = await obraService.updateObra(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ mensaje: 'Obra no encontrada' });
    }
    res.json({ mensaje: 'Obra actualizada correctamente' });
  } catch (error) {
    console.error('Error al actualizar obra:', error.message);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

const deleteObra = async (req, res) => {
  try {
    const deleted = await obraService.deleteObra(req.params.id);
    if (!deleted) {
      return res.status(404).json({ mensaje: 'Obra no encontrada' });
    }
    res.json({ mensaje: 'Obra eliminada correctamente' });
  } catch (error) {
    console.error('Error al eliminar obra:', error.message);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

module.exports = {
  getAllObras,
  getObraById,
  createObra,
  updateObra,
  deleteObra
};
