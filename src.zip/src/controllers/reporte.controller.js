const ReporteService = require('../services/reporte.service');

const getAllReportes = async (req, res, next) => {
  try {
    res.json(await ReporteService.getAllReportes());
  } catch (err) {
    next(err);
  }
};

const getReporteById = async (req, res, next) => {
  try {
    res.json(await ReporteService.getReporteById(req.params.id));
  } catch (err) {
    next(err);
  }
};

const createReporte = async (req, res, next) => {
  try {
    const id = await ReporteService.createReporte(req.body);
    res.status(201).json({ message: 'Reporte creado', id_reporte: id });
  } catch (err) {
    next(err);
  }
};

module.exports = { getAllReportes, getReporteById, createReporte };
