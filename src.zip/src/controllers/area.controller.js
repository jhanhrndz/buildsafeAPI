const AreaService = require('../services/area.service');

const getAllAreas = async (req, res, next) => {
  try { res.json(await AreaService.getAllAreas()); }
  catch (err) { next(err); }
};

const getAreaById = async (req, res, next) => {
  try { res.json(await AreaService.getAreaById(req.params.id)); }
  catch (err) { next(err); }
};

const createArea = async (req, res, next) => {
  try {
    const id = await AreaService.createArea(req.body);
    res.status(201).json({ message: 'Área creada', id_area: id });
  } catch (err) { next(err); }
};

const updateArea = async (req, res, next) => {
  try {
    await AreaService.updateArea(req.params.id, req.body);
    res.json({ message: 'Área actualizada' });
  } catch (err) { next(err); }
};

const deleteArea = async (req, res, next) => {
  try {
    await AreaService.deleteArea(req.params.id);
    res.json({ message: 'Área eliminada' });
  } catch (err) { next(err); }
};

module.exports = { getAllAreas, getAreaById, createArea, updateArea, deleteArea };
