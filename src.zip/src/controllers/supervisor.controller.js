const SupervisorService = require('../services/supervisor.service');

const getAllSupervisores = async (req, res, next) => {
  try {
    const list = await SupervisorService.getAllSupervisores();
    res.json(list);
  } catch (err) {
    next(err);
  }
};

const getSupervisorById = async (req, res, next) => {
  try {
    const sup = await SupervisorService.getSupervisorById(req.params.id);
    res.json(sup);
  } catch (err) {
    next(err);
  }
};

const createSupervisor = async (req, res, next) => {
  try {
    // Aquí debes haber hasheado la contraseña antes de llamar al servicio:
    // por ejemplo, en un middleware o directamente en el controller:
    const { contrasena, ...rest } = req.body;
    const bcrypt = require('bcrypt');
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(contrasena, salt);

    const id = await SupervisorService.createSupervisor({
      ...rest,
      contrasena_hashed: hash
    });
    res.status(201).json({ message: 'Supervisor creado', id_supervisor: id });
  } catch (err) {
    next(err);
  }
};

const updateSupervisor = async (req, res, next) => {
  try {
    await SupervisorService.updateSupervisor(req.params.id, req.body);
    res.json({ message: 'Supervisor actualizado' });
  } catch (err) {
    next(err);
  }
};

const deleteSupervisor = async (req, res, next) => {
  try {
    await SupervisorService.deleteSupervisor(req.params.id);
    res.json({ message: 'Supervisor eliminado' });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAllSupervisores,
  getSupervisorById,
  createSupervisor,
  updateSupervisor,
  deleteSupervisor
};
