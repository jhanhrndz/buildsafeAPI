const Svc = require('../services/coordinador.service');

exports.getAll = async (req,res,next) => {
  try { res.json(await Svc.getAll()); } catch(e){ next(e); }
};
exports.getById = async (req,res,next) => {
  try { res.json(await Svc.getById(req.params.id)); } catch(e){ next(e); }
};
exports.create = async (req,res,next) => {
  try { const id = await Svc.create(req.body); res.status(201).json({ id_coordinador:id }); } catch(e){ next(e); }
};
exports.update = async (req,res,next) => {
  try { await Svc.update(req.params.id, req.body); res.json({ message:'Coordinador actualizado' }); } catch(e){ next(e); }
};
exports.delete = async (req,res,next) => {
  try { await Svc.remove(req.params.id); res.json({ message:'Coordinador eliminado' }); } catch(e){ next(e); }
};
