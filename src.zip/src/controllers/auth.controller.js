const AuthService = require('../services/auth.service');

const register = async (req, res, next) => {
  try {
    const id = await AuthService.register(req.body);
    res.status(201).json({ message: 'Coordinador registrado', id_coordinador: id });
  } catch (err) {
    next(err);
  }
};

const login = async (req, res, next) => {
  try {
    const { usuario, contrasena } = req.body;
    const result = await AuthService.login(usuario, contrasena);
    res.json({ message: 'Login exitoso', ...result });
  } catch (err) {
    next(err);
  }
};

module.exports = { register, login };
