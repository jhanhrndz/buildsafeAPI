const Coord = require('../models/coordinador.model');

const getAll = () => Coord.findAll();
const getById = async (id) => {
  const item = await Coord.findById(id);
  if (!item) throw { status: 404, message: 'Coordinador no encontrado' };
  return item;
};
const create = (data) => Coord.create(data);
const update = async (id, data) => {
  const count = await Coord.updateById(id, data);
  if (!count) throw { status: 404, message: 'Coordinador no encontrado' };
};
const remove = async (id) => {
  const count = await Coord.deleteById(id);
  if (!count) throw { status: 404, message: 'Coordinador no encontrado' };
};
module.exports = { getAll, getById, create, update, remove };
