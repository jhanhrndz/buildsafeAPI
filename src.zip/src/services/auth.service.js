const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const AuthModel = require('../models/auth.model');

const register = async (data) => {
  const { usuario, contrasena } = data;
  const existing = await AuthModel.findUserByUsername(usuario, 'coordinador');
  if (existing) throw { status: 409, message: 'Usuario ya registrado' };

  const salt = await bcrypt.genSalt(10);
  const hash = await bcrypt.hash(contrasena, salt);
  const id = await AuthModel.createCoordinador({ ...data, contrasena_hashed: hash });
  return id;
};

const login = async (usuario, contrasena) => {
  // intentamos coordinador
  let user = await AuthModel.findUserByUsername(usuario, 'coordinador');
  let role = 'coordinador';
  if (!user) {
    user = await AuthModel.findUserByUsername(usuario, 'supervisor');
    role = 'supervisor';
  }
  if (!user) throw { status: 401, message: 'Usuario no encontrado' };

  const ok = await bcrypt.compare(contrasena, user.contrasena_hashed);
  if (!ok) throw { status: 401, message: 'Contraseña incorrecta' };

  const token = jwt.sign(
    { id: user[ role === 'coordinador' ? 'id_coordinador' : 'id_supervisor'], usuario, rol: role },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );
  return { token, rol: role };
};

module.exports = { register, login };
