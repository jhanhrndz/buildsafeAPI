const Reporte = require('../models/reporte.model');

const getAllReportes = () => Reporte.findAll();

const getReporteById = async (id) => {
  const r = await Reporte.findById(id);
  if (!r) throw { status: 404, message: 'Reporte no encontrado' };
  return r;
};

const createReporte = async (data) => {
  // data: { id_camara, fecha_hora, imagen_url, id_categoria, descripcion }
  const id_reporte = await Reporte.insertReporte(data);

  await Reporte.insertInfraccion({
    id_reporte,
    id_epp: data.id_categoria, 
    nombre: data.descripcion     
  });

  return id_reporte;
};


module.exports = { getAllReportes, getReporteById, createReporte };
