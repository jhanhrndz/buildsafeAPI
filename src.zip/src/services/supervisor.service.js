const Supervisor = require('../models/supervisor.model');

const getAllSupervisores = () => Supervisor.findAll();

const getSupervisorById = async (id) => {
  const sup = await Supervisor.findById(id);
  if (!sup) throw { status: 404, message: 'Supervisor no encontrado' };
  return sup;
};

const createSupervisor = async (data) => {
  // data debe traer usuario, contrasena_hashed, documento, nombres, apellidos, correo, telefono
  const id = await Supervisor.create(data);
  return id;
};

const updateSupervisor = async (id, data) => {
  const count = await Supervisor.updateById(id, data);
  if (count === 0) throw { status: 404, message: 'Supervisor no encontrado' };
};

const deleteSupervisor = async (id) => {
  const count = await Supervisor.deleteById(id);
  if (count === 0) throw { status: 404, message: 'Supervisor no encontrado' };
};

module.exports = {
  getAllSupervisores,
  getSupervisorById,
  createSupervisor,
  updateSupervisor,
  deleteSupervisor
};
