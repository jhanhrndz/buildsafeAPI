const Area = require('../models/area.model');

const getAllAreas = () => Area.findAll();

const getAreaById = async (id) => {
  const area = await Area.findById(id);
  if (!area) throw { status: 404, message: 'Área no encontrada' };
  return area;
};

const createArea = (data) => Area.create(data);

const updateArea = async (id, data) => {
  const affected = await Area.updateById(id, data);
  if (affected === 0) throw { status: 404, message: 'Área no encontrada' };
};

const deleteArea = async (id) => {
  const affected = await Area.deleteById(id);
  if (affected === 0) throw { status: 404, message: 'Área no encontrada' };
};

module.exports = { getAllAreas, getAreaById, createArea, updateArea, deleteArea };
