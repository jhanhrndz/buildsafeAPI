const obraModel = require('../models/obra.model');

const createObra = async (data) => {
  const id = await obraModel.insertObra(data);
  return id;
};

const getAllObras = async () => {
  return await obraModel.findAllObras();
};

const getObraById = async (id) => {
  return await obraModel.findObraById(id);
};

const updateObra = async (id, data) => {
  return await obraModel.updateObraById(id, data);
};

const deleteObra = async (id) => {
  return await obraModel.deleteObraById(id);
};

module.exports = {
  createObra,
  getAllObras,
  getObraById,
  updateObra,
  deleteObra
};
