// File: src/middlewares/verificarrol.middleware.js
exports.verificarRol = (...allowedRoles) => {
  return (req, res, next) => {
    const { rol } = req.user;
    if (!allowedRoles.includes(rol)) {
      return res.status(403).json({ error: 'Acceso denegado: rol insuficiente' });
    }
    next();
  };
};
