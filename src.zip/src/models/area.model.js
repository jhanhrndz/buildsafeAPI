const connectToDatabase = require('../config/db');

const findAll = async () => {
  const db = await connectToDatabase();
  const [rows] = await db.query(`
    SELECT a.*, o.nombre AS nombre_obra, s.nombres AS nombre_supervisor, s.apellidos AS apellido_supervisor
    FROM area a
    JOIN obra o ON a.id_obra = o.id_obra
    LEFT JOIN supervisor s ON a.id_supervisor = s.id_supervisor
  `);
  return rows;
};

const findById = async (id) => {
  const db = await connectToDatabase();
  const [rows] = await db.query(`
    SELECT a.*, o.nombre AS nombre_obra, s.nombres AS nombre_supervisor, s.apellidos AS apellido_supervisor
    FROM area a
    JOIN obra o ON a.id_obra = o.id_obra
    LEFT JOIN supervisor s ON a.id_supervisor = s.id_supervisor
    WHERE a.id_area = ?
  `, [id]);
  return rows[0];
};

const create = async (data) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    INSERT INTO area (id_obra, id_supervisor, nombre, descripcion)
    VALUES (?, ?, ?, ?)
  `, [data.id_obra, data.id_supervisor || null, data.nombre, data.descripcion]);
  return result.insertId;
};

const updateById = async (id, data) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    UPDATE area SET id_supervisor = ?, nombre = ?, descripcion = ?
    WHERE id_area = ?
  `, [data.id_supervisor || null, data.nombre, data.descripcion, id]);
  return result.affectedRows;
};

const deleteById = async (id) => {
  const db = await connectToDatabase();
  const [result] = await db.query('DELETE FROM area WHERE id_area = ?', [id]);
  return result.affectedRows;
};

module.exports = { findAll, findById, create, updateById, deleteById };
