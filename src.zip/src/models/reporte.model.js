const connectToDatabase = require('../config/db');

const findAll = async () => {
  const db = await connectToDatabase();
  const [rows] = await db.query(`
    SELECT r.*, 
           c.ip_stream AS camara_ip_stream, 
           a.nombre AS nombre_area,
           o.nombre AS nombre_obra,
           cat.nombre AS categoria_epp,
           epp.nombre AS nombre_infraccion
    FROM reporte r
    JOIN camara c ON r.id_camara = c.id_camara
    JOIN area a ON c.id_area = a.id_area
    JOIN obra o ON a.id_obra = o.id_obra
    JOIN infraccion_epp epp ON r.id_reporte = epp.id_reporte
    JOIN categoria_epp cat ON epp.id_epp = cat.id_epp
  `);
  
  return rows;
};

const findById = async (id) => {
  const db = await connectToDatabase();
  const [rows] = await db.query(`
    SELECT r.*, 
           c.ip_stream AS camara_ip_stream,
           a.nombre AS nombre_area,
           o.nombre AS nombre_obra,
           cat.nombre AS categoria_epp,
           epp.nombre AS nombre_infraccion
    FROM reporte r
    JOIN camara c ON r.id_camara = c.id_camara
    JOIN area a ON c.id_area = a.id_area
    JOIN obra o ON a.id_obra = o.id_obra
    JOIN infraccion_epp epp ON r.id_reporte = epp.id_reporte
    JOIN categoria_epp cat ON epp.id_epp = cat.id_epp
    WHERE r.id_reporte = ?
  `, [id]);
  
  return rows[0];
};

const insertReporte = async ({ id_camara, fecha_hora, imagen_url }) => {
  const db = await connectToDatabase();
  const [result] = await db.query(
    `INSERT INTO reporte (id_camara, fecha_hora, imagen_url)
     VALUES (?, ?, ?)`,
    [id_camara, fecha_hora, imagen_url]
  );
  return result.insertId;
};

const insertInfraccion = async ({ id_reporte, id_epp, nombre }) => {
  const db = await connectToDatabase();
  await db.query(
    `INSERT INTO infraccion_epp (id_reporte, id_epp, nombre)
     VALUES (?, ?, ?)`,
    [id_reporte, id_epp, nombre]
  );
};


module.exports = {
  findAll,
  findById,
  insertReporte,
  insertInfraccion
};
