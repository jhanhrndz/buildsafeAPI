const connectToDatabase = require('../config/db');

const findAll = async () => {
  const db = await connectToDatabase();
  const [rows] = await db.query('SELECT * FROM supervisor');
  return rows;
};

const findById = async (id) => {
  const db = await connectToDatabase();
  const [rows] = await db.query('SELECT * FROM supervisor WHERE id_supervisor = ?', [id]);
  return rows[0];
};

const create = async (data) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    INSERT INTO supervisor (usuario, contrasena_hashed, documento, nombres, apellidos, correo, telefono)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `, [
    data.usuario,
    data.contrasena_hashed,
    data.documento,
    data.nombres,
    data.apellidos,
    data.correo,
    data.telefono
  ]);
  return result.insertId;
};

const updateById = async (id, data) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    UPDATE supervisor
    SET usuario = ?, documento = ?, nombres = ?, apellidos = ?, correo = ?, telefono = ?
    WHERE id_supervisor = ?
  `, [
    data.usuario,
    data.documento,
    data.nombres,
    data.apellidos,
    data.correo,
    data.telefono,
    id
  ]);
  return result.affectedRows;
};

const deleteById = async (id) => {
  const db = await connectToDatabase();
  const [result] = await db.query('DELETE FROM supervisor WHERE id_supervisor = ?', [id]);
  return result.affectedRows;
};

module.exports = { findAll, findById, create, updateById, deleteById };
