const connectToDatabase = require('../config/db');

const findAll = async () => {
  const db = await connectToDatabase();
  const [rows] = await db.query('SELECT * FROM coordinador');
  return rows;
};

const findById = async (id) => {
  const db = await connectToDatabase();
  const [rows] = await db.query('SELECT * FROM coordinador WHERE id_coordinador = ?', [id]);
  return rows[0];
};

const create = async (data) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    INSERT INTO coordinador (documento, nombres, apellidos, correo, telefono)
    VALUES (?, ?, ?, ?, ?)
  `, [data.documento, data.nombres, data.apellidos, data.correo, data.telefono]);
  return result.insertId;
};

const updateById = async (id, data) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    UPDATE coordinador
    SET documento=?, nombres=?, apellidos=?, correo=?, telefono=?
    WHERE id_coordinador=?
  `, [data.documento, data.nombres, data.apellidos, data.correo, data.telefono, id]);
  return result.affectedRows;
};

const deleteById = async (id) => {
  const db = await connectToDatabase();
  const [result] = await db.query('DELETE FROM coordinador WHERE id_coordinador = ?', [id]);
  return result.affectedRows;
};

module.exports = { findAll, findById, create, updateById, deleteById };
