const connectToDatabase = require('../config/db');

const findUserByUsername = async (username, table) => {
  const db = await connectToDatabase();
  const [rows] = await db.query(
    `SELECT * FROM ${table} WHERE usuario = ?`,
    [username]
  );
  return rows[0];
};

const createCoordinador = async ({ usuario, contrasena_hashed, documento, nombres, apellidos, correo, telefono }) => {
  const db = await connectToDatabase();
  const [result] = await db.query(
    `INSERT INTO coordinador (usuario, contrasena_hashed, documento, nombres, apellidos, correo, telefono)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [usuario, contrasena_hashed, documento, nombres, apellidos, correo, telefono]
  );
  return result.insertId;
};

module.exports = { findUserByUsername, createCoordinador };
