const connectToDatabase = require('../config/db');

const findAllObras = async () => {
  const db = await connectToDatabase();
  const [rows] = await db.query(`
    SELECT o.*, c.nombres AS coordinador_nombre, c.apellidos AS coordinador_apellido
    FROM obra o
    JOIN coordinador c ON o.id_coordinador = c.id_coordinador
  `);
  return rows;
};

const findObraById = async (id) => {
  const db = await connectToDatabase();
  const [rows] = await db.query(`
    SELECT o.*, c.nombres AS coordinador_nombre, c.apellidos AS coordinador_apellido
    FROM obra o
    JOIN coordinador c ON o.id_coordinador = c.id_coordinador
    WHERE o.id_obra = ?
  `, [id]);
  return rows[0];
};

const insertObra = async ({ id_coordinador, nombre, descripcion, fecha_inicio, estado }) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    INSERT INTO obra (id_coordinador, nombre, descripcion, fecha_inicio, estado)
    VALUES (?, ?, ?, ?, ?)
  `, [id_coordinador, nombre, descripcion, fecha_inicio, estado]);
  return result.insertId;
};

const updateObraById = async (id, { nombre, descripcion, fecha_inicio, estado }) => {
  const db = await connectToDatabase();
  const [result] = await db.query(`
    UPDATE obra SET nombre = ?, descripcion = ?, fecha_inicio = ?, estado = ?
    WHERE id_obra = ?
  `, [nombre, descripcion, fecha_inicio, estado, id]);
  return result.affectedRows;
};

const deleteObraById = async (id) => {
  const db = await connectToDatabase();
  const [result] = await db.query('DELETE FROM obra WHERE id_obra = ?', [id]);
  return result.affectedRows;
};

module.exports = {
  findAllObras,
  findObraById,
  insertObra,
  updateObraById,
  deleteObraById
};
