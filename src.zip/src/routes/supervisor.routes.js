const router = require('express').Router();
const ctrl = require('../controllers/supervisor.controller');
const { authenticateToken } = require('../middlewares/auth.middleware');
const { verificarRol } = require('../middlewares/verificarrol.middleware');


// Listar y ver detalles (solo coordinador o supervisor)
router.get('/',  ctrl.getAllSupervisores);
router.get('/:id',  ctrl.getSupervisorById);

// Crear, actualizar, eliminar (solo coordinador)
router.post('/',  ctrl.createSupervisor);
router.put('/:id',ctrl.updateSupervisor);
router.delete('/:id', ctrl.deleteSupervisor);

module.exports = router;
