const express = require('express');
const router = express.Router();

//middlewares
const { authenticateToken } = require('../middlewares/auth.middleware');
const {verificarRol, verficarRoles} = require('../middlewares/verificarrol.middleware');
const errorHandler = require('../middlewares/error.middleware');
const verificarToken = require('../middlewares/verificartoken.middleware');

const authRoutes = require('./auth.routes');
router.use('/auth', authRoutes);

// A partir de aquí, todas requieren token válido
//router.use(authenticateToken);

// Rutas protegidas
const coordinadorRoutes = require('./coordinador.routes');
const obraRoutes         = require('./obra.routes');
const areaRoutes         = require('./area.routes');
const camaraRoutes       = require('./camara.routes');
const reporteRoutes      = require('./reporte.routes')
const supervisorRoutes = require('./supervisor.routes');

// CRUD principales
router.use('/coordinadores', coordinadorRoutes);
router.use('/obras', obraRoutes);
router.use('/areas', areaRoutes);
router.use('/camaras', camaraRoutes);
router.use('/reportes', reporteRoutes);
router.use('/supervisores', supervisorRoutes);

// capa de dominio (pyton detect)
const previewRoutes     = require('./preview.routes');
const streamRoutes      = require('./stream.routes');

router.use('/reportes',         previewRoutes);   // POST /reportes/preview
router.use('/stream',   streamRoutes);    // GET /stream/:camId



//gestion de errores
router.use(errorHandler);

module.exports = router;
