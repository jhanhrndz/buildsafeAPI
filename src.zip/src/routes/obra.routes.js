const express = require('express');
const router = express.Router();
const {
  getAllObras,
  getObraById,
  createObra,
  updateObra,
  deleteObra
} = require('../controllers/obra.controller');

router.get('/', getAllObras);
router.get('/:id', getObraById);
router.post('/', createObra);
router.put('/:id', updateObra);
router.delete('/:id', deleteObra);

module.exports = router;
