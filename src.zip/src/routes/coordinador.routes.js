const r = require('express').Router();
const ctrl = require('../controllers/coordinador.controller');
const { verificarRol } = require('../middlewares/verificarrol.middleware');

r.get('/', ctrl.getAll);
r.get('/:id', ctrl.getById);
r.post('/', ctrl.create);
r.put('/:id', ctrl.update);
r.delete('/:id', ctrl.delete);

module.exports = r;
