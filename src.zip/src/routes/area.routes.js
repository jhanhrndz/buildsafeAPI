const express = require('express');
const router = express.Router();
const AreaController = require('../controllers/area.controller');
const { verificarRol } = require('../middlewares/verificarrol.middleware');

// Listar y ver detalles (supervisor, coordinador)
router.get('/', AreaController.getAllAreas);
router.get('/:id',  AreaController.getAreaById);

// Crear, actualizar, eliminar (solo coordinador)
router.post('/',AreaController.createArea);
router.put('/:id',  AreaController.updateArea);
router.delete('/:id', AreaController.deleteArea);

module.exports = router;
